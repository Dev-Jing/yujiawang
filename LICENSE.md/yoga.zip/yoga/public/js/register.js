
$("#footer").load("footer.html");

 //创建 [用户名,密码] 正则验证

    var regUname=/^0?(13|14|15|16|17|18)[0-9]{9}$/; //用于验证手机号
    var regUpwd=/^[0-9a-zA-Z]{8}$/; //用于验证密码

    var userName=$("#uname");
    var userPassword=$("#upwd");
    var userAgainPassword=$("#againPwd");
    var submitBtn=$("#LoginSubmit");

 //为uname和upwd输入框绑定失去焦点事件
    var valiName;
    var valiPwd;
    var vali=function(reg,txt){
        if(reg.test(txt.val())){
            txt.css("border","1px solid #CBCBCB");
            return true;
        }else{
            txt.css("border","1px solid #f00");
            return false;
        }
    };
    userName.blur(function(){
        valiName=vali(regUname,$(this));
    });
    userPassword.blur(function(){
        valiPwd=vali(regUpwd,$(this));

    });

//为againPwd输入框绑定失去焦点事件

    userAgainPassword.blur(function(){
        if(userAgainPassword.val()===userPassword.val()){
            userAgainPassword.css("border","1px solid #CBCBCB");
            return true;
       }else{
            userAgainPassword.css("border","1px solid #f00");
            return false;
        }
    });

/*提交注册信息*/
    submitBtn.click(function(){
    if(valiName&&valiPwd){
        /*判断当前手机号是否已经注册*/
        $.ajax({
            type:'POST',
            url:'/register_reg',
            data:{uname:userName.val()},
            success:function(result){
                if(result.code===200){
                    /*提交注册*/
                    $.ajax({
                             type:'POST',
                             url:'/register_add',
                             data:{
                                 uname:userName.val(),
                                 upwd:userPassword.val()
                             },
                             success:function(consequence){
                                if(consequence.code===200){
                                    location.href="login.html";
                                }else{
                                    alert("注册失败 ！"+consequence.msg);
                                }
                             }
                         });
                }else{
                    alert("注册失败 ！"+result.msg);
                }
            }
        });
    }else{
        alert("请完善信息后再提交 ！");
    }
});


/*==================================*/
//var registUrl = "/index.php/Home/Index/regist.html",
//    countdown = 60, //初始化倒计时时间
//    close, //倒计时开关
//    myreg = /^0?(13|14|15|16|17|18)[0-9]{9}$/; //正则表达式，用于验证手机号
//$(function(){
//    //获取短信验证码
//    $('#messageCode').click(function(){
//        var usertel = $('#usertel').val();//当前输入手机号
//        if(usertel){
//            if(!myreg.test(usertel) || usertel.length!=11){
//                alert('请输入有效的手机号码！');
//                return false;
//            }else{
//                $('body').append('<div class="opacity8" id="opacity8"></div>');
//                $('#tipBox').removeClass('Cui_hidden');
//                $('#mcap-text').keyup(function(){
//                    var myregs = /^[1-9A-Za-z]{4}$/;
//                    var tcode = $("#mcap-text").val();
//                    if(tcode.length == 4){
//                        if(myregs.test(tcode)){
//                            var a = new Object();
//                            a.code = tcode;
//                            a.type = 'regist';
//                            a.phone_num = usertel;
//                            $.post( "/index.php/home/index/tcode_verify.html" , a , function(data,status){
//                                if(data.status == 'ok'){
//                                    close = setInterval(function(){
//                                        count();
//                                    },1000)//执行定时器
//                                    alert('验证码已发送，请查收');//执行发送短信方法
//                                }else{
//                                    alert(data.msg);
//                                }
//                                $('#opacity8').remove();
//                                $('#tipBox').addClass('Cui_hidden');
//                            });
//                        }else{
//                            alert('验证码错误');
//                        }
//                    }
//                });
//            }
//        }else{
//            alert('手机号不能为空');
//            return false;
//        }
//    });
//
//    //取消验证码层
//    $("body").on("click","#opacity8",function(){
//        $('#opacity8').remove();
//        $('#tipBox').addClass('Cui_hidden');
//    });
//
//    //提交注册
//    $("#regBtn").click(function(){
//        var usertel = $('#usertel').val();//当前输入手机号
//        if($("#deal").prop("checked")){ //是否接受注册条款
//            var a = new Object();
//            a.pass = $("#password").val();
//            a.repass = $("#againpassword").val();
//            a.code = $("#ccap-text").val();
//            a.acount = usertel;
//            if(usertel){
//                if(!myreg.test(usertel) || usertel.length!=11){
//                    alert('请输入有效的手机号码！')
//                    return false;
//                }else{
//                    if(a.code){
//                        if($('#againpassword').val() == $('#password').val() && $('#password').val()){
//                            $.post( registUrl , a , function(data,status){
//                                if(data.status == 'ok'){
//                                    alert('注册成功，欢迎来到瑜伽网！');
//                                    setTimeout(function(){
//                                        window.location.href = "/index.php/home/index/index.html"
//                                    },1000);
//                                }else{
//                                    alert(data.msg);
//                                }
//                            });
//                        }else{
//                            alert('两次密码输入不相同');
//                            return false;
//                        }
//                    }else{
//                        alert('验证码不能为空');
//                        return false;
//                    }
//                }
//            }else{
//                alert('手机号不能为空');
//                return false;
//            }
//        }else{
//            alert('请阅读并确认用户协议！')
//        }
//    });
//})
////计时更新函数
//function count(){
//    var this_time = $('#messageCode');
//    if (countdown == 0) {
//        this_time.attr("disabled",false);
//        this_time.val('免费获取验证码');
//        clearInterval(close);
//        countdown = 60;
//        return;
//    } else {
//        this_time.attr("disabled",true);
//        this_time.val('重新发送(' + countdown + ')');
//        countdown--;
//    }
//}