/*功能点1： 异步请求页头和页尾*/
$("#header").load("header.html",function(){
    if(sessionStorage["loginUname"]==undefined){

    }else{
        $("#welcome").html("欢迎回来瑜伽网 ："+"<a href='personal.html'title='去个人中心'>"+sessionStorage['loginUname']+"</a>");
        $("#exit").css("display","inline");
        $("#without").css("display","none");
    }
});
$("#footer").load("footer.html");
$("#asideRt").load("recommend.html");


/*视频列表选页*/
$(function(){
    var p=$("#sort");
    p.children("a").click(function(e){
        e.preventDefault();
        $(this).siblings("a").removeClass("active");
        $(this).addClass("active");
        var id=$(this).attr("href");
        p.siblings("div").css("z-index",1);
        p.siblings(id).css("z-index",100);
    });
})
