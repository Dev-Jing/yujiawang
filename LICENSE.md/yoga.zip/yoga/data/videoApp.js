const pool=require("./pool");
module.exports =(req, res)=>{
    pool.getConnection((err,conn)=>{
        conn.query("SELECT * FROM yg_video",(err,videoList)=>{
            res.json(videoList);
            conn.release();
        });
    });
};