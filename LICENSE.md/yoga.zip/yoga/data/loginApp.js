const pool=require("./pool");

module.exports=(req,res)=>{
    var uname=req.body.uname;
    var upwd=req.body.upwd;
    pool.getConnection((err,conn)=>{
        conn.query("SELECT uid FROM yg_user WHERE uname=? AND upwd=?",[uname,upwd],(err,result)=>{
            if(err){
                var data={"code":500,"msg":"服务器忙，请稍后重试 ！"}
            }else if(result.length===0){
                var data={"code":400,"msg":"用户不存在 ！"}
            }else{
                var data={"code":200,"msg":"登陆成功 ！","uid":result[0].uid}
            }
            res.json(data);
            conn.release();
        });
    });
};